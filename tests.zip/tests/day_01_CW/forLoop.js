// let sum = 0;

// for (let i = 1; i <= 10; i++) {
//   sum += i;

//   if (i !== 10) {
//     console.log(`${sum} + ${i + 1} = ${sum + i + 1}`);
//   } else {
//     console.log(`Final Sum: ${sum}`);
//   }
// }
// let sum = 0;

// for (let i = 1; i <= 10; i++) {
//   sum += i;
// }

// console.log(`Final Sum: ${sum}`);
let val = 10;

for (let i = 1; i <= val; i++) {
  if (i % 2 !== 0) {
    console.log(i);
  }
}
