/*Use new Javascript File Name: 02_Conditional.js
 
    Objective: Learn if - else and switch - case
    Create 2 functions : launchBrowser, runTests
    where,
    a) launchBrowser need to take input as browserName (string) and do not return any
        - use if, else (chrome or otherwise)
        - just print
    b) runTests need to take input as testType (string) and do not return any
        - use switch case (smoke, sanity, regression, default (smoke))
        - just do print
 
    Call that function from the javascript
 
    Time: 15 Minutes
    */

function launchBrowser(browserName){
    if(browserName == 'Chrome'){
        console.log('Launching chrome browser')
    }else
    console.log('Launch the default browser')
}
launchBrowser('chrome')

function runTests(testType){
    switch (testType) {
        case 'smoke':
            console.log('Execute the test in chrome')
            break;
        case 'sanity':
            console.log('Execute the test in firefox')
            break;
        case 'regression':
            console.log('Execute the test in edge')
            break;
        default:
            console.log('Execute the test in webkit')
            break;
    }
}
runTests('smoke')