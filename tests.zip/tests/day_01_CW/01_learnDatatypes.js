/*Javascript File Name: 01_learn.js
 
    Objective: Learn Primitive Data Types
 
    Create the following variables using let (not using var) and check their typeOf
 
    a) firstName
    b) companyName
    c) mobileNumber
    d) isAutomation
    e) hasPlaywright (do not assign)
 
    print and confirm the values and data types
 
    Time: 10 Minutes (including setup)

    */

let firstName = "Ranjini";
let companyName = "Testleaf";
let mobileNumber = 8122401758;
let isAutomation = true;
let hasPlaywright;

console.log(typeof(firstName));
console.log(typeof(companyName));
console.log(typeof(mobileNumber));
console.log(typeof(isAutomation));
console.log(typeof(hasPlaywright));

