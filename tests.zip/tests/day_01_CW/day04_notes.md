Week 2 Day 2 Agenda: Dig deeper into Playwright

2.30 - Recap and Revise (Salesforce testcase)
3.00 - Additional Locators
3.30 - Synchronization/Auto waiting
4.00 - Classroom (Salesforce testcase)
4.45 - Playwright Configuration file - Video, Tracing
5.30 - Classroom (Salesforce testcase with config)
6.00 - Video & Tracing with Code
6.20 - Classroom (Video and Tracing)
6.30 - Wrap