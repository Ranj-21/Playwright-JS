Agenda [Saturday]

- Function Overloading & usecase
- Error Handling and Debugging (test debug)
- Alerts, Frame, Shadow DOM
- Window
- File Upload, Download

### Dialog
    Dialog in the context of Playwright refers to a way to interact with or handle dialog boxes that appear in web applications. 
    Dialogs are typically pop-up boxes that can include alerts, confirmations, or prompts. These dialogs are often used to capture user input or to display important information.

Playwright's API allows you to handle these dialogs in various ways:

1. **Listening to the `dialog` event:** You can listen to the `dialog` event on the `page` object. This event is emitted whenever a dialog is created in the page. By listening to this event, you can interact with the dialog, like accepting or dismissing it, and even provide input if it's a prompt dialog.

2. **Interacting with the Dialog Object:** When a dialog event is triggered, it includes a `Dialog` object. This object provides methods like `accept([promptText])`, `dismiss()`, and properties like `type()`, `message()`, which can be used to interact with and get information about the dialog.

