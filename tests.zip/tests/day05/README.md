### Introduction to TypeScript
    - TypeScript is an open-source programming language developed by Microsoft. 
    - It is a superset of JavaScript, which means that any valid JavaScript code is also valid  TypeScript code. 
    - TypeScript adds static typing and other features to JavaScript, making it a more powerful and     structured language for large-scale application development.
