// let studentName = 'Ranjini';
// studentName = 25;
// Number
var height = 6.1;
// String
var empName = 'Ranjini';
var message = "Hello, ".concat(empName);
// Boolean
var isStudent = true;
// undefined
var companyName;
// null
var pincode = null;
// any
var address;
console.log(typeof (height));
console.log(typeof (message));
console.log(typeof (isStudent));
console.log(typeof (companyName));
console.log(typeof (pincode));
console.log(typeof (address));
