let age = 25;
age = 'Testleaf';
console.log(age);