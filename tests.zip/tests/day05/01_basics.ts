// let studentName = 'Ranjini';
// studentName = 25;

// Number
let height:number = 6.1

// String
let empName: string = 'Ranjini';
let message: string = `Hello, ${empName}`;

// Boolean
let isStudent: boolean = true;

// undefined
let companyName: string;

// null
let pincode: null = null;

// any
let address;

console.log(typeof(height));
console.log(typeof(message));
console.log(typeof(isStudent));
console.log(typeof(companyName));
console.log(typeof(pincode));
console.log(typeof(address));
