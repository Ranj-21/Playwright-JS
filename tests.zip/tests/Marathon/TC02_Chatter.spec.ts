import { test, chromium } from "@playwright/test";
import { TIMEOUT } from "dns";

test("Lead to Opportunity conversion",async ({page}) => {

    await page.goto("https://login.salesforce.com/");
    await page.fill("#username", "ranjini.r@testleaf.com");
    await page.fill("#password", "Testleaf$1234");
    await page.click("#Login");
    await page.waitForLoadState("load");
    await page.click(".slds-icon-waffle");
    await page.getByText("View All").click();
    await page.getByPlaceholder("Search apps or items...").fill("Service");
    await page.click('mark:text-is("Service")');
    await page.click('a[title="Cases"]');
    await page.click('div[title="New"]');
    await page.getByPlaceholder('Search Contacts...').click();
    await page.locator('span.slds-media__body').last().click();
    await page.locator("div[class*='salutation'] a").click();
    await page.getByTitle('Ms.').click();
    await page.getByPlaceholder('First Name').fill("Ranjini");
    await page.getByPlaceholder('Last Name').fill("R");
    await page.getByRole('button',{name:'Save', exact:true}).click();
    
    
});