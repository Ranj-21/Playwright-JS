import { test, chromium } from "@playwright/test";
import { TIMEOUT } from "dns";

test("Lead to Opportunity conversion",async ({page}) => {

    await page.goto("https://login.salesforce.com/");
    await page.fill("#username", "ranjini.r@testleaf.com");
    await page.fill("#password", "Testleaf$1234");
    await page.click("#Login");
    await page.waitForLoadState("load");
    await page.click(".slds-icon-waffle");
    await page.getByText("View All").click();
    await page.getByPlaceholder("Search apps or items...").fill("Marketing");
    await page.click('mark:has-text("Marketing")');
    await page.click('a[title="Leads"]');
    await page.click('div[title="New"]');
    await page.getByLabel('Salutation, --None--').click();
    await page.getByTitle('Ms.').click();
    await page.getByPlaceholder('First Name').fill("Ranjini");
    await page.getByPlaceholder('Last Name').fill("R");
    await page.fill("[name='Company']", "Testleaf");
    await page.getByRole('button', {name:'Save',exact: true }).click();
    const text = await page.innerText('.forceToastMessage');
    console.log(`Verified Text: ${text}`);
    await page.waitForLoadState('load');
    await page.click("li[class='slds-dropdown-trigger slds-dropdown-trigger_click slds-button_last overflow']");
    await page.locator('div.slds-dropdown__item').last().click();    
    await page.locator("button[class='slds-button transparentButton']").last().click();
    await page.locator("input[class=' input']").last().clear();
    await page.locator("input[class=' input']").last().fill("Qeagle");
    await page.getByRole('button', {name:'Convert', exact: true}).click();
    const title = await page.innerText("div.title h2");
    console.log(`Verified Text: ${title}`);
    await page.getByRole('button', {name:'Go to Leads', exact: true}).click();
    const search = page.getByPlaceholder('Search this list...');
    const lead = await search.fill("Ranjini");
    await search.press('Enter');
    const records = await page.innerText("div[class='emptyContentInner slds-text-align_center'] span");
    console.log(records);
    await page.getByRole('link', { name: 'Opportunities', exact:true }).click();
    const opportunity = page.getByPlaceholder('Search this list...');
    const searchOpp = opportunity.fill("Qeagle");
    opportunity.press('Enter');
    await page.locator("a[title='Qeagle']").first().click();
    const oppVer = await page.locator("div.slds-media__body h1").last().innerText();
    console.log(`Opportunity created: ${oppVer}`);
    
});