// Define a class named 'Bicycle'
class Bicycle {
    // Properties
   brand: string = 'Hercules';  //instance variable
   // speed: number = 15;
   weight: number = 20.5;
    isElectric:boolean = true;

    // Methods
   private cycleInfo(): void{
        //local variable
        let model: number = 2020;
        console.log(`Hello, My cycle brand is ${this.brand} and ${this.weight}`);
        console.log(`The model year is ${model}`);
    }
}
   // Calling the method

    const myInstance = new Bicycle();
    myInstance.cycleInfo();
     