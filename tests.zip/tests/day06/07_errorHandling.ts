import {Browser} from "./05_interface"

class OpenFirefox implements Browser {
    
    browserName: string = 'Firefox';

    startApp(): void {
        console.log(`${this.browserName} app is starting.`);
    }

    loginCredentials(username: string, password: string): string {

        return username+" "+password;
       
    }

    getStatus(): boolean {
        return true;
    }
}

const myFirefox = new OpenFirefox();

try {
    myFirefox.startApp();
    myFirefox.loginCredentials("Demosalesmanager", "crmsfa");
    const status =myFirefox.getStatus();
    console.log(`Status: ${status}`);
} catch (error) {
    console.error(`Failed to open Firefox`);
}
