// Implementation
function click(locator) {
    if (locator === undefined) {
        console.log("The button is clicked");
        return; // Return type is void
    }
    else if (locator === "id") {
        return "id locator is selected";
    }
    else {
        return "id contains numbers";
    }
}
// Function Calls
click(); // The button is clicked
click("id"); // id contains numbers
