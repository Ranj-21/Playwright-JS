import { log } from "console";

class LoginPage{

     browserName: string;
     browserVersion: string;

    constructor(bName:string, bVersion:string){
      this.browserName = bName;
      this.browserVersion = bVersion;
      console.log(bName, bVersion);
      
    }
    signUp(username: string, password: string): string {
        return username + " " +password; 
    }

}
const myLogin = new LoginPage("chrome", "117v");
const cred = myLogin.signUp("Demosalesmanager", "crmsfa");
console.log(`The credentias are ${cred}`);
/**
 * Classwork - 2
 * 
 * Scenario: Manage a shopping cart with methods for adding/removing items and completing the 
   checkout process.
 * Class: ShoppingCart
   Methods: addItem(), removeItem(), checkout(AccountName,CardNumber)
   Create an instance for the class and call the methods
   
 * 
 * 
 */
