Class:

A class is a blueprint for creating objects. It defines a set of properties (variables) and methods (functions) that will be common to all instances of that class.
Classes are a way to implement the principles of object-oriented programming, such as encapsulation, inheritance, and polymorphism.
In TypeScript, you can use the class keyword to declare a class.

Variables:

In the context of a class, variables are often referred to as properties. These are the characteristics or attributes that define the state of an object.
Properties are declared within a class and represent the data members of the class.

Methods are functions defined within a class. They represent the behavior or actions that objects of the class can perform.
Methods can interact with the class properties to modify or retrieve their values.

Objects:

An object is an instance of a class. It's a concrete realization of the class blueprint, with its own unique state and behavior.
Objects are created using the new keyword followed by the class name and optional constructor arguments.


In TypeScript, a constructor is a special method within a class that is automatically called when an instance of the class is created using the new keyword. The primary purpose of a constructor is to initialize the properties of the class and perform any setup or initialization logic that is necessary before the object is ready for use.

Function:

A function in TypeScript is a standalone block of code that can be defined outside of a class.
It can be declared using the function keyword, as shown in the example above.
Functions can be global (defined in the global scope) or nested within other functions.
Method:

A method is a function that is a member of a class or an object.
Methods are associated with a particular class or object and are defined within the curly braces of the class.
Methods can access and modify the properties of the class and are often used to represent the behavior of objects.