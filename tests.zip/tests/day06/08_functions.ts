/**
 * firstname (mandatory)
 * email (mandatory)
 * lastname (mandatory)
 * city : optional
 * age: optional
 */

//to make any parameter option : ? 

//note: optional parameter should always come after mandatory parameters

function click(fname:string, lname:string, email:string, city?:string, age?:number){
    console.log(`sign up with ${fname} ${lname} ${email} ${city} ${age}`)

}

click("Ranjini", "R", "rr@gmail.com");

// Default parameters

function type(userName:string= 'Demosalesmanager' , password:string){
    console.log(`Sign In with ${userName} ${password}`)

}

type("Ranjini", "crmsfa");
