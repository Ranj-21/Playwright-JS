import {test } from "@playwright/test";
test("w3schhols",async ({page}) => {
    
    await page.goto("https://www.w3schools.com/js/tryit.asp?filename=tryjs_confirm")
    page.on("dialog", async (dialog) => {
        const message = 'Ajay'; // Replace with the desired text
        console.log('Dialog Message:', dialog.message());
        await dialog.accept();
    });
 
    const iframe = page.frameLocator('#iframeResult');
    await iframe.locator("button:has-text('Try it')").click()
 
    await page.waitForTimeout(5000)
})
