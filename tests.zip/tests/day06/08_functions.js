/**
 * firstname (mandatory)
 * email (mandatory)
 * lastname (mandatory)
 * city : optional
 * age: optional
 */
//to make any parameter option : ? 
//note: optional parameter should always come after mandatory parameters
function click(fname, lname, email, city, age) {
    console.log("sign up with ".concat(fname, " ").concat(lname, " ").concat(email, " ").concat(city, " ").concat(age));
}
click("Ranjini", "R", "rr@gmail.com");
// Default parameters
function type(userName, password) {
    if (userName === void 0) { userName = 'Demosalesmanager'; }
    console.log("Sign In with ".concat(userName, " ").concat(password));
}
type("Ranjini", "crmsfa");
