// Function Overloads
function calculateArea(shape: "rectangle", width: number, height: number): number;
function calculateArea(shape: "circle", radius: number): number;

// Function Implementation
function calculateArea(shape: "rectangle" | "circle", widthOrRadius: number, height: number): number {
    if (shape === "rectangle") {
        // Area of a rectangle: width * height
        return widthOrRadius * height;
    } else {
        // Area of a circle: π * r^2
        return Math.PI * Math.pow(widthOrRadius, 2);
    }
}

// Function Calls
const rectangleArea = calculateArea("rectangle", 5, 10);
//const circleArea = calculateArea("circle", 3);

console.log(rectangleArea); 
//console.log(circleArea);    
