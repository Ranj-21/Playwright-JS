interface Browser{

   // browserName: string = "Chrome";
   browserName: string;
   startApp(): void;
   loginCredentials(username:string, password:string): string;
   getStatus(): boolean
}
interface Element{

   findElement(): string;
   
}
export {Browser,Element}

/**
 * Classwork: 3
 * 
 * 
 * 
 */