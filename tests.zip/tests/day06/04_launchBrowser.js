"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var LoginPage = /** @class */ (function () {
    function LoginPage(bName, bVersion) {
        this.browserName = bName;
        this.browserVersion = bVersion;
        console.log(bName, bVersion);
    }
    LoginPage.prototype.signUp = function (username, password) {
        return username + " " + password;
    };
    return LoginPage;
}());
var myLogin = new LoginPage("chrome", "117v");
var cred = myLogin.signUp("Demosalesmanager", "crmsfa");
console.log("The credentias are ".concat(cred));
/**
 * Classwork - 2
 *
 * Scenario: Manage a shopping cart with methods for adding/removing items and completing the
   checkout process.
 * Class: ShoppingCart
   Methods: addItem(), removeItem(), checkout(AccountName,CardNumber)
   Create an instance for the class and call the methods
   
 *
 *
 */
