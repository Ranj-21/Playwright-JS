import {Browser} from "./05_interface"
class OpenChrome implements Browser {
    browserName: string;
    startApp(): void {
        throw new Error("Method not implemented.");
    }
    loginCredentials(): string {
        throw new Error("Method not implemented.");
    }
    getStatus(): boolean {
        throw new Error("Method not implemented.");
    }

    
}