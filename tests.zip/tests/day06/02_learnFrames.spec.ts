import { test, chromium } from "@playwright/test";

test("Handle iFrames",async ({page}) => {

    await page.goto("https://leafground.com/frame.xhtml");
    const frameLocator = page.frameLocator('iframe').first();
    await frameLocator.locator('#Click').click();
   
    const cardLocator = page.locator(".card").filter({hasText:' Click Me (Inside Nested frame)'});
    const frame =  cardLocator.frameLocator("iframe");
    await frame.frameLocator("iframe").locator('#Click').click();

    const cardLocator1 = page.locator(".card").filter({hasText:'How many frames in this page?'});
    page.waitForLoadState("load")
    const frameCount = await  cardLocator1.frameLocator("iframe").locator('#Click').count();
    console.log(`No. of frames ${frameCount}`);
    
})